//
//  Copyright (c) 2016, Linaro Limited. All rights reserved.
//
//  SPDX-License-Identifier: BSD-2-Clause-Patent
//
//

#include <Base.h>
#include <Library/ArmSmcLib.h>

VOID
ArmCallSmc (
  IN OUT ARM_SMC_ARGS *Args
  )
{
}
